import { useState } from 'react';
import { Search, Filter, ShieldAlert, ShieldCheck, Clock, FileText, CheckCircle2, XCircle } from 'lucide-react';
import { KYCRequest } from '../types';

const mockData: KYCRequest[] = [
  { id: 'KYC-8829', name: 'Oluwaseun Adebayo', bvn: '223****8912', status: 'verified', timestamp: '2 mins ago', riskScore: 12 },
  { id: 'KYC-8830', name: 'Ngozi Eze', bvn: '221****4451', status: 'pending', timestamp: '5 mins ago', riskScore: 45 },
  { id: 'KYC-8831', name: 'Ibrahim Musa', bvn: '229****9901', status: 'failed', timestamp: '12 mins ago', riskScore: 89 },
  { id: 'KYC-8832', name: 'Chioma Okafor', bvn: '224****1123', status: 'verified', timestamp: '1 hr ago', riskScore: 5 },
  { id: 'KYC-8833', name: 'Abubakar Yusuf', bvn: '228****5567', status: 'verified', timestamp: '2 hrs ago', riskScore: 8 },
];

export function KYC() {
  const [search, setSearch] = useState('');

  return (
    <div className="p-8 max-w-7xl mx-auto w-full h-full flex flex-col">
      <div className="mb-8 flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">Instant KYC Verification</h1>
          <p className="text-slate-400 mt-1">AI-powered identity verification (BVN, NIN, OCR)</p>
        </div>
        <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium transition-colors">
          Run Batch Verification
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex items-center gap-4">
          <div className="p-3 bg-indigo-500/10 rounded-lg">
            <Clock className="w-6 h-6 text-indigo-400" />
          </div>
          <div>
            <p className="text-sm text-slate-400">Avg. Processing Time</p>
            <p className="text-xl font-bold text-slate-100">&lt; 60 seconds</p>
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex items-center gap-4">
          <div className="p-3 bg-emerald-500/10 rounded-lg">
            <ShieldCheck className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <p className="text-sm text-slate-400">Auto-Approval Rate</p>
            <p className="text-xl font-bold text-slate-100">92.4%</p>
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex items-center gap-4">
          <div className="p-3 bg-amber-500/10 rounded-lg">
            <ShieldAlert className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <p className="text-sm text-slate-400">Fraud Flag Rate</p>
            <p className="text-xl font-bold text-slate-100">2.1%</p>
          </div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl flex-1 flex flex-col min-h-0 overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex gap-4 items-center">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input 
              type="text" 
              placeholder="Search by name, BVN, or ID..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 placeholder:text-slate-600"
            />
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-slate-800 text-slate-300 hover:text-white rounded-lg text-sm font-medium transition-colors border border-slate-700">
            <Filter className="w-4 h-4" />
            Filter
          </button>
        </div>
        
        <div className="overflow-x-auto flex-1">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-sm">
                <th className="px-6 py-4 font-medium">Request ID</th>
                <th className="px-6 py-4 font-medium">Applicant Name</th>
                <th className="px-6 py-4 font-medium">BVN Match</th>
                <th className="px-6 py-4 font-medium">Risk Score</th>
                <th className="px-6 py-4 font-medium">Time</th>
                <th className="px-6 py-4 font-medium">Status</th>
                <th className="px-6 py-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {mockData.map((req) => (
                <tr key={req.id} className="hover:bg-slate-800/20 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-slate-300">{req.id}</td>
                  <td className="px-6 py-4 text-sm text-slate-200">{req.name}</td>
                  <td className="px-6 py-4 text-sm text-slate-400 font-mono">{req.bvn}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${
                      req.riskScore < 20 ? 'bg-emerald-500/10 text-emerald-400' :
                      req.riskScore < 60 ? 'bg-amber-500/10 text-amber-400' :
                      'bg-rose-500/10 text-rose-400'
                    }`}>
                      {req.riskScore}/100
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500">{req.timestamp}</td>
                  <td className="px-6 py-4 text-sm">
                    <div className="flex items-center gap-2">
                      {req.status === 'verified' && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                      {req.status === 'pending' && <Clock className="w-4 h-4 text-amber-500" />}
                      {req.status === 'failed' && <XCircle className="w-4 h-4 text-rose-500" />}
                      <span className={`capitalize ${
                        req.status === 'verified' ? 'text-emerald-400' :
                        req.status === 'pending' ? 'text-amber-400' :
                        'text-rose-400'
                      }`}>{req.status}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="text-indigo-400 hover:text-indigo-300 text-sm font-medium">
                      Review
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
