import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ShieldCheck, MessageSquare, Briefcase, Activity } from 'lucide-react';

const data = [
  { name: 'Jan', loans: 400, recovered: 240 },
  { name: 'Feb', loans: 300, recovered: 139 },
  { name: 'Mar', loans: 550, recovered: 380 },
  { name: 'Apr', loans: 450, recovered: 390 },
  { name: 'May', loans: 700, recovered: 480 },
  { name: 'Jun', loans: 900, recovered: 800 },
];

export function Overview() {
  return (
    <div className="p-8 max-w-7xl mx-auto w-full">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-100">Overview</h1>
        <p className="text-slate-400 mt-1">Platform metrics and system health</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard 
          title="Total Processed" 
          value="45.2k" 
          trend="+12%" 
          icon={Briefcase} 
          iconColor="text-blue-400" 
          bg="bg-blue-400/10" 
        />
        <MetricCard 
          title="KYC Success Rate" 
          value="98.4%" 
          trend="+1.2%" 
          icon={ShieldCheck} 
          iconColor="text-emerald-400" 
          bg="bg-emerald-400/10" 
        />
        <MetricCard 
          title="Active AI Agents" 
          value="1,204" 
          trend="+5%" 
          icon={MessageSquare} 
          iconColor="text-indigo-400" 
          bg="bg-indigo-400/10" 
        />
        <MetricCard 
          title="Recovery Rate" 
          value="76.8%" 
          trend="+4.3%" 
          icon={Activity} 
          iconColor="text-amber-400" 
          bg="bg-amber-400/10" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="mb-6">
            <h3 className="font-semibold text-slate-200">Volume & Recovery Trends</h3>
            <p className="text-sm text-slate-500">Loan distribution vs AI-driven recoveries over time</p>
          </div>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorLoans" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorRecovered" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f1f5f9' }}
                  itemStyle={{ color: '#cbd5e1' }}
                />
                <Area type="monotone" dataKey="loans" stroke="#4f46e5" strokeWidth={2} fillOpacity={1} fill="url(#colorLoans)" />
                <Area type="monotone" dataKey="recovered" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorRecovered)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col">
          <div className="mb-6">
            <h3 className="font-semibold text-slate-200">System Activity</h3>
            <p className="text-sm text-slate-500">Real-time gateway logs</p>
          </div>
          <div className="flex-1 space-y-4 overflow-y-auto pr-2">
            {[
              { m: 'WhatsApp Intake processing completed', t: '2m ago', s: 'success' },
              { m: 'NIN OCR Verification failed', t: '5m ago', s: 'error' },
              { m: 'AI Agent #442 initiated recovery flow', t: '12m ago', s: 'info' },
              { m: 'NDPA Compliance audit logged', t: '15m ago', s: 'success' },
              { m: 'New tenant verification pending', t: '18m ago', s: 'warning' },
              { m: 'BVN mismatch detected', t: '24m ago', s: 'error' },
            ].map((log, i) => (
              <div key={i} className="flex items-start gap-3 border-b border-slate-800/50 pb-3 last:border-0">
                <div className={`mt-0.5 w-2 h-2 rounded-full shrink-0 ${
                  log.s === 'success' ? 'bg-emerald-500' : 
                  log.s === 'error' ? 'bg-rose-500' : 
                  log.s === 'warning' ? 'bg-amber-500' : 'bg-blue-500'
                }`} />
                <div>
                  <p className="text-sm text-slate-300">{log.m}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{log.t}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, trend, icon: Icon, iconColor, bg }: any) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-slate-400 text-sm font-medium">{title}</p>
          <h4 className="text-2xl font-bold text-slate-100 mt-2">{value}</h4>
        </div>
        <div className={`p-2 rounded-lg ${bg}`}>
          <Icon className={`w-5 h-5 ${iconColor}`} />
        </div>
      </div>
      <div className="mt-4 flex items-center text-sm">
        <span className="text-emerald-400 font-medium">{trend}</span>
        <span className="text-slate-500 ml-2">vs last month</span>
      </div>
    </div>
  );
}
