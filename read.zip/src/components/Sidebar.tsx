import { LayoutDashboard, FileInput, ShieldCheck, FileKey2, PhoneOutgoing } from 'lucide-react';
import { ViewState } from '../types';

interface SidebarProps {
  currentView: ViewState;
  onViewChange: (view: ViewState) => void;
}

export function Sidebar({ currentView, onViewChange }: SidebarProps) {
  const navItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'intake', label: 'Loan Intake', icon: FileInput },
    { id: 'kyc', label: 'KYC Verification', icon: ShieldCheck },
    { id: 'compliance', label: 'Compliance Engine', icon: FileKey2 },
    { id: 'recovery', label: 'Intelligent Recovery', icon: PhoneOutgoing },
  ] as const;

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col h-full text-slate-300 shrink-0">
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-indigo-600 flex items-center justify-center shrink-0">
            <span className="font-bold text-white tracking-wider">SS</span>
          </div>
          <span className="font-semibold text-lg text-white">ShadowSpark</span>
        </div>
        <div className="text-[10px] text-slate-500 mt-2 uppercase tracking-wider font-semibold">Lodgist AI Micro-Services</div>
      </div>
      
      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onViewChange(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
              currentView === item.id 
                ? 'bg-indigo-600/10 text-indigo-400' 
                : 'hover:bg-slate-800 hover:text-white'
            }`}
          >
            <item.icon className="w-5 h-5 shrink-0" />
            {item.label}
          </button>
        ))}
      </nav>
      
      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800/50 rounded p-3 text-xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span>System Status</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
          </div>
          <p className="text-slate-500">Vercel AI Gateway Connected</p>
        </div>
      </div>
    </aside>
  );
}
