/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Overview } from './components/Overview';
import { KYC } from './components/KYC';
import { ViewState } from './types';
import { PhoneOutgoing, FileKey2, FileInput } from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewState>('overview');

  const renderContent = () => {
    switch (currentView) {
      case 'overview':
        return <Overview />;
      case 'kyc':
        return <KYC />;
      case 'intake':
        return <PlaceholderView title="Automated Loan Intake" desc="Manage WhatsApp conversational intake flows." icon={FileInput} />;
      case 'compliance':
        return <PlaceholderView title="The Compliance Engine" desc="NDPA workflows, consent management, and WORM audit logs." icon={FileKey2} />;
      case 'recovery':
        return <PlaceholderView title="Intelligent Recovery" desc="AI recovery agents via WhatsApp and SMS." icon={PhoneOutgoing} />;
      default:
        return <Overview />;
    }
  };

  return (
    <div className="flex h-screen w-full bg-slate-950 overflow-hidden text-slate-200">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      <main className="flex-1 overflow-y-auto relative h-full">
        {renderContent()}
      </main>
    </div>
  );
}

function PlaceholderView({ title, desc, icon: Icon }: any) {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center p-8">
      <div className="w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center mb-6 border border-slate-800">
        <Icon className="w-8 h-8 text-indigo-500" />
      </div>
      <h2 className="text-2xl font-bold text-slate-200 mb-2">{title}</h2>
      <p className="text-slate-500 max-w-md">{desc}</p>
      <button className="mt-8 px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium transition-colors">
        Configure Module
      </button>
    </div>
  );
}
