export type ViewState = 'overview' | 'intake' | 'kyc' | 'compliance' | 'recovery';

export interface DashboardMetrics {
  totalLoans: number;
  approvalRate: number;
  kycSuccessRate: number;
  activeAgents: number;
  recoveredAmount: number;
}

export interface KYCRequest {
  id: string;
  name: string;
  bvn: string;
  status: 'pending' | 'verified' | 'failed';
  timestamp: string;
  riskScore: number;
}
